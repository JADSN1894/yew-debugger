import './app.css';

document.querySelector('#app').innerHTML = `
  <button class="btn">Hello daisyUI</button>
`;
